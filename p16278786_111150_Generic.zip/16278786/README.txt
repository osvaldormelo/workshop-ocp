==============================
Interim Patch for Bug: 16278786
==============================

Date: Wed Jun 19 16:09:06 2013
---------------------------------
Platform Patch for   : Generic
Product Patched      : Oracle SOA Platform
Product Version      : 11.1.1.5.0
Auto Enabled         : Yes

This document describes how to install the interim patch for
bug # 16278786. It includes the following sections: 

	Section 1, "Prerequisites"

	Section 2, "Pre-Installation Instructions"

	Section 3, "Installation Instructions"

	Section 4, "Post-Installation Instructions"

	Section 5, "Deinstallation Instructions"

	Section 6, "Post Deinstallation Instructions" 

	Section 7, "Bugs Fixed by This Patch" 

1 Prerequisites
----------------

Ensure that you meet the following requirements before you install or
deinstall the patch:
	
1. Before applying the non-mandatory patches, ensure that you have the
   exact symptoms described in the bug.

2. Review and download the latest version of OPatch 11.1.x via Bug 6880880.
   (OPatch version 11.1.0.8.2 or higher)
   a. Oracle recommends that all customers be on the latest version of OPatch.
      Review the My Oracle Support note 224346.1, and follow the instructions
      to update to the latest version if needed. Click the following link to
      view the note: 
  
      Note 224346.1  - Opatch - Where Can I Find the Latest Version of Opatch?
      https://support.oracle.com/CSP/main/article?cmd=show&type=NOT&id=224346.1

   b. For FMW Opatch usage, refer to the document at:
      http://download.oracle.com/docs/cd/E21764_01/doc.1111/e16793/opatch.htm
   If you choose the AUTO option, do the following:
   - Starting with OPatch 11.1.0.8.2+ the -AUTO flag asks for the
     Node Manager username and password. For more information on how
     to check, verify, or modify the Node Manager username and password,
     review the My Oracle Support note 1146793.1, available in the
     following link:

     Note 1146793.1 - How to check/verify/modify Node Manager username &
                      password?
     https://support.oracle.com/CSP/main/article?cmd=show&type=NOT&id=1146793.1

3. Verify the OUI Inventory.
   OPatch needs access to a valid OUI inventory to apply patches. 
   Validate the OUI inventory with the following commands:

   $ opatch lsinventory  

   If the command errors out, contact Oracle Support and work to validate
   and verify the inventory setup before proceeding.

4. Confirm the executables appear in your system PATH.

   The patching process will use the unzip and the OPatch executables. After
   setting the ORACLE_HOME environment, confirm if the following executables
   exist, before proceeding to the next step:

	- which opatch
	- which unzip

   If either of these executables do not show in the PATH, correct the
   problem before proceeding.

5. Create a location for storing the unzipped patch. This location
   will be referred to later in the document as PATCH_TOP.
    NOTE: On WINDOWS, the prefrred location is the drive root directory. 
    For example, "C:\PATCH_TOP" and avoid choosing locations like, 
    "C:\Documents and Settings\username\PATCH_TOP". 
    This is necessary due to the 256 characters limitation on windows     
    platform. 
Follow Steps 6 and 7 only if you choose to use the AUTO flag:

6. To configure Node Manager, do the following: 

   With the AUTO flag, the OPatch utility uses WLST with the Node Manager to
   start/shutdown the required WLS server(s) - Admin server and/or Managed
   Server(s).

   To properly configure the Node Manager, follow below instructions:

   a. Create or validate the nodemanager.properties file, which by default is
      located at:

        [MW_HOME]/[WLS_HOME]/common/nodemanager (on UNIX operating systems), or
        [MW_HOME]\[WLS_HOME]\common\nodemanager (on Windows operating
        systems) directory.
           
        For Example:
        /opt/product/fmw11g/wlserver_10.3/common/nodemanager/nodemanager.properties
  
   b. Add or validate the following lines onto the nodemanager.properties
      file:
  
        StartScriptEnabled=true
        StopScriptEnabled=true

   c. Ensure NodeManager is running by using:

        [MW_HOME]/[WLS_HOME]/server/bin/startNodeManager.sh (UNIX)
        [MW_HOME]\[WLS_HOME]\server\bin\startNodeManager.cmd (Windows)

7. To set the Machine Name and Listen Address, follow the instructions listed
   below: 

   The Machine Name and Listen Address can be blank on a default installation. 
   For the AUTO option:

   The Machine Name for each WebLogic Server (including the Administration
   Server) must be set to a valid value. It cannot be set to blank or None.

   The Listen Address of the Administration and Managed Servers must be set to
   the real physical host's address (hostname, FQDN, or IP address).
   It cannot be set to blank or localhost.
 
   a. To configure the Managed Server(s), do the following within the WLS
      Admin Console:
  
     i.   In the Domain Structure, navigate to:
          > [DOMAIN_NAME] > Environments > Machines

     ii.  Click the 'Lock & Edit' button on the left hand side 
          (if WLS is in Production mode)

     iii. Create a new machine, by clicking the 'NEW' button; give it a name,
          and choose Unix, for example,
          if you are in an unix environment (at 'Machine OS').

     iv.  Select the Machine you've just created and  navigate as
          instructed below:
          Configuration > Node Manager

          Change the 'Listen Address' to [HOST_NAME]
          (For example, the host which the Node Manager is listening).
	  Click Save.

     v.   In the Domain Structure navigate to:
          > [DOMAIN_NAME] > Environments > Servers

     vi.  Click on each server (bam_server1, soa_server1),
          assign the Machine you've created in step iii. Additionaly type in
          within 'Listen Address' the name of the host where the NodeManager is
          running. Click Save.

     vii. Click the 'Activate Changes' button on the left hand side 
          (if WebLogic Server is in Production mode)
  
     Note:
     -----
        If WebLogic Server is in Development mode steps ii & vii will not be
        needed.

    b. To configure the Administration Server within the WebLogic Server Admin
       Console, do as instructed below:

        i.   Stop the Administration Server and all the Managed Servers.

        ii.  If WLS is in Production mode, Take a backup of the existing
             config.xml file of the WebLogic Server domain.

             The default one is at:
             [MW_HOME]/user_projects/domains/[DOMAIN_NAME]/config/config.xml

             Modify the config.xml as instructed below:

             Search for AdminServer entry, and add to it the entries listed
             below:

             <machine>[HOST_NAME]</machine>
             <listen-address>[HOST_NAME]</listen-address>

             Save the file.

        iii. If WebLogic Server is in Development mode, assign the Machine
             you've created previously, and click Save.
             Additionally, type in within Listen Address, the name of the
             host where the Node Manager is running.

    c.  In the WebLogic Server Admin Console, change the hostname
        verification for the Administration Server, and proceed as
        instructed below:
    
        i.   Click the 'Lock & Edit' button on the left hand side 
             (if in Production mode).

        ii.  In Domain Structure navigate to:
             > [DOMAIN_NAME] > Environments > Servers

        iii. Click on the AdminServer, and then within the Configuration
             tab and over the SSL subtab.

        iv.  Click within the Advanced link and then change the 'Hostname
             Verification' from 'BEA Hostname Verifier' to 'None'.

        v.   Click Save.

        vi.  Click the 'Activate Changes' button on the left hand side
             (if WLS is in Production mode)

        vii. Restart the Admin Server.
   
        Note: 
        ----
          a. If the WLS is in Development mode steps i & vi will not be needed.
          b. If the WebLogic Server doesn't start, revert the config.xml
             and contact the Oracle Support.



2 Pre-Installation Instructions
-------------------------------


Set the ORACLE_HOME environment variable to SOA Home, 
for example "[MW_HOME]/Oracle_SOA1" directory.

   Patch Apply Modes: (for Oracle_SOA1 (SOA Home)):
   ------------------------------------------------

      With AUTO flag:
        The Admin Server and Node Manager have to be running for OPatch
        -auto operations. The Managed Servers may or may not be in a running
        state. OPatch will bounce all the local servers and the servers
        sharing the Middleware Home affected by the patch. If the patch
        affects an application deployed on the Administration Server, the
        Administration Server will also be bounced. If the Managed Servers
        are not running, OPatch won't restart the affected servers. It is
        the user's responsibility to start the servers in order to uptake
        the patch.

      Without AUTO flag:
        No servers need to be started. At the end of the patch apply, all
        servers must be (re-)started to uptake the patch.


3 Installation Instructions
---------------------------

1. Unzip the patch zip file into the PATCH_TOP.

   $ unzip -d PATCH_TOP p16278786_111150_Generic.zip

    NOTE: In WINDOWS, the unzip command might not work as this zip has 
    certain contents which passes the 256 characters limit. 
    To overcome this problem, please use alternate ZIP utility like 
    7-Zip to unzip the patch. 
 
    For example: To unzip using 7-zip, run the command: 
         "c:\Program Files\7-Zip\7z.exe"  x p14302931_111154_Generic.zip 

2. Set your current directory to the directory where the patch is located.

   $ cd PATCH_TOP/16278786

3. Run OPatch to apply the patch.

   Note:
   -----
   Though this patch is AUTO flag enabled, the user still has the choice
   to apply it without the AUTO option. However doing so involves manual 
   restarting of the affected servers.

   - If applying without AUTO, run thefollowing command:

       $ opatch apply

    - If applying with AUTO, run the following command:

       $ opatch apply -auto            

  Note:
  -----
  i. The user would be prompted  for the following inputs by OPatch
     to complete the auto patch application process.

    AdminUser          : <Enter the WebLogic Admin Server username>
    AdminPassword      : <Enter the WebLogic Admin Server password>
    AdminServerURL     : <Enter the WebLogic Admin Server URL>
    DomainHome         : <Enter the WebLogic domain directory location>
    ApplicationsDir    : <Enter the WebLogic applications directory location
      (default location is [MW_HOME]/user_projects/applications/[DOMAIN_NAME]>
    NodeManagerUser    : <Enter the NodeManager username>
    NodeManagerPassword: <Enter the NodeManager password>

   Ensure that the input values are exact and correct, to avoid undesired
   patch failures. 	  

  ii. At the end of "opatch apply -auto" command, if you see the WARNING
  message as given below:
  
       The following warnings have occurred during OPatch execution:
       1) OUI-67851:
       All the applications affected by this patch are deployed in 'No Stage'
       mode.
       Redeploy operation will not be performed for the affected applications.
       Please refer to the log file for more details.

       This may occur because the OPatch expects secure connections. Please
       kindly review the log file to be sure.

When OPatch starts, it validates the patch and makes sure that there are no
conflicts with the software already installed in the ORACLE_HOME.
  OPatch categorizes two types of conflicts:

     a. Conflicts with a patch already applied to the ORACLE_HOME
        In this case, stop the patch installation, and contact Oracle Support
        Services.

     b. Conflicts with subset patch already applied to the ORACLE_HOME
        In this case, continue the install, as the new patch contains all the
        fixes from the existing patch in the ORACLE_HOME.


4 Post-Installation Instructions
---------------------------------

1. In case, you have opted to apply without AUTO:
   - Restart all servers (Admin Server and all Managed Server(s))

2. In case, you have opted to apply with AUTO:
   - No Action Needed.

5 Deinstallation Instructions
------------------------------

If you experience any problems after installing this patch, remove the patch as
follows:

1. Make sure to follow the same Prerequisites or pre-install steps (if any)
   when deinstalling a patch.  
   This includes setting up any environment variables like ORACLE_HOME and
   verifying the OUI inventory before deinstalling.

2. Change to the directory where the patch was unzipped.

   $ cd PATCH_TOP/16278786

3. Run OPatch to deinstall the patch.

   a. If rolling back without AUTO , run following command:               
       $ opatch rollback -id 16278786
                          
   b. If rolling back with AUTO, run following command:
       $ opatch rollback -id 16278786 -auto


6 Post Deinstallation Instructions
-----------------------------------
1. In case, you have opted to apply without AUTO:
   - Restart all servers (Admin Server and all Managed Server(s))

2. In case, you have opted to apply with AUTO:
   - No Action Needed.

7 Bugs Fixed by This Patch
--------------------------
The following are the bugs fixed by this patch:

  16278786: DESIGN TIME ERROR IN JDEVELOPER 11.1.1.5 WHEN INTEGRATING DB ADAPTER WITH MICROS

-----------------------------------------------------------------------------
DISCLAIMER:

This interim patch has only undergone basic unit testing, and has not been
through a complete test cycle generally followed for a production patch set. 
Though the fixes in this document rectifies the bug, Oracle Corporation will
not be responsible for other issues that may arise due to these fixes. 
Oracle Corporation recommends to later upgrade to the next production patch
set, when available. Applying this patch could overwrite other interim
patches applied since the last patch set. Customers need to make a request
to Oracle Support for a patch that includes those fixes, as well as inform
Oracle Support about all the patches installed when a Service Request is
opened. Please download, test, and provide feedback as soon as possible
to assist in the timely resolution of this problem.

Copyright (c) 2012, Oracle and/or its affiliates. All rights reserved.
-----------------------------------------------------------------------------

